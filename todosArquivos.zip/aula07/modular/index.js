const express = require('express');
const app = express();
const rotasUsuarios = require('./rotasUsuarios');
const rotasProdutos = require('./rotasProdutos');
const port = 3000;

app.use('/usuarios', rotaUsuarios);
app.use('/produtos', rotasProdutos);

app.get('/', (req, res) => {
    res.status(200).send('<h1>Pagina inicial</h1>');
});

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});