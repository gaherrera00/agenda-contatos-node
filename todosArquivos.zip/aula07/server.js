const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());
app.use(express.urlencoded(extended, true));

app.get('/', (req, res) => {
    res.send('<h1>Pagina inicial</h1>');
});

app.options('/produtos/:id', (req, res) => {
})

app.get('/usuarios/:id', (req, res) => {
    const id = req.params.id;
    res.send(`Detalhes do usuario com ID: ${id}`);
});

app.get('/categorias/:categoria', (req, res) => {
    const categoria = req.params.categoria;
    res.send(`Categoria: ${categoria}`);
});

app.get('/produtos/:idProdutos', (req, res) => {
    const idProdutos = req.params.idProdutos;
    res.send(`ID do produto: ${idProdutos}`);
});

app.post('/produtos', (req, res) => {
    const novoProduto = req.body;
    console.log('Novo produto: ', novoProduto);
    res.send('Produto criando com sucesso!!!')
});

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
