const buscarDados = require('./funcaoAssincrona');

describe('Funcao buscar dados', () => {
    it('retornar os dados do json', () => {
        return buscarDados()
            .then(data => {
                expect(data).toBeDefined();
                expect(data.userId).toBe(1);
                expect(data.id).toBe(1);
                expect(data.title).toBe("delectus aut autem");
                expect(data.completed).toBe(false);

            })
    })
})