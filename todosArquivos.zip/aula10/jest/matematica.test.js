
const {somar, dividir} = require('./matematica.js');

describe("Funcao somar: ", () => {
    it('deve somar a mais b', () => {
        expect(somar(2, 3)).toBe(5);
    })
    it('deve somar numeros positivos e negativos', () => {
        expect(somar(-2, 3)).toBe(1);
    })
    it('deve somar numeros negativos', () => {
        expect(somar(-2, -2)).toBe(-4);
    })

})

describe("Funcao dividir: ", () => {
    it('deve dividir a mais b', () => {
        expect(dividir(10, 2)).toBe(5);
    })
})