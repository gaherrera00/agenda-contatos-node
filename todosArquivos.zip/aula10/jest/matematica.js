function somar(a, b) {
    return a + b;
}

function dividir(a, b) {
    return a / b;
}

module.exports = {
    somar: somar,
    dividir: dividir
};

