import chalk from "chalk";
import axios from "axios";
import inquirer from "inquirer";

const API_URL = 'http://localhost:3000';

async function listarProdutos() {

    try {
        const response = await axios.get(`${API_URL}/produtos`);
        return response.data
    } catch (error) {
        console.error(chalk.red.inverse('Erro ao listar produtos: '), error.message);
    }
}

async function exibirDetalhesProduto(id) {
    try {
        const response = await axios.get(`${API_URL}/produtos/${id}`)
        return response.data;
    } catch (error) {
        console.error(chalk.red.inverse(`Erro ao exibir detalhes do produto com ID: ${id}`), error.message);
        return null;
    }
}

async function exibirMenu() {
    const perguntas = [
        {
            type: 'list',
            name: 'opcao',
            message: chalk.yellow.inverse('Escolha uma opcao: '),
            choices: [
                { name: chalk.blue.inverse('Listar produtos'), value: 'listar' },
                { name: chalk.green.inverse('Exibir detalhes do produto'), value: 'exibir' },
                { name: chalk.red.inverse('Sair'), value: 'sair' }

            ]
        }
    ];
    try {
        const resposta = await inquirer.prompt(perguntas);
        if (Array.isArray(produtos) && produtos.length > 0) {
            console.log(chalk.green('Lista de produtos: '));
            produtos.forEach(produto => {
                console.log(`- ${chalk.cyan(produto.id)}: ${chalk.green(produto.nome)}: ${chalk.yellow(produto.preco)}`);

            });
        } else {
            console.log(chalk.yellow('Nenhum produto encontrado.'));
        }
        switch (resposta.opcao) {
            case 'listar':
                const produtos = await listarProdutos();

                if (produtos){
                    console.log(chalk.green('Lista de produtos: '));
                    produtos.forEach(produto => {
                        console.log(`- ${chalk.cyan(produto.id)}: ${chalk.green(produto.nome)}: ${chalk.yellow(produto.preco)}`);

                    });
                } else {
                    console.log(chalk.yellow('Nenhum produto encontrado.'));
                }
                exibirMenu()
                break;
            case 'exibir':
            case 'sair':
                break;
        }

    } catch (error) {
        console.error(chalk.red.inverse('Ocorreu um erro'), error)
    }
}
exibirMenu();