// CRIAR DIRETORIO
const fs = require('fs');
const nomePasta = 'moduloPATH';
try {
    if (!fs.existsSync(nomePasta)) {
        fs.mkdirSync(nomePasta);
    }
} catch (err) {
    console.error(err);
}

// EXCLUIR DIRETORIO
// const fs = require('fs');
fs.rmdir('moduloPATH/moduloPATH', (err) => {
    if (err) {
        console.log('Erro ao excluir diretório:', err);
    } else {
        console.log('Diretório excluído com sucesso');
    }
});

//CRIAR DOCUMENTO
// const fs = require('fs');
fs.writeFile('TESTE.txt', 'testesteste', err => {
    if (err) throw err;
    console.log('Arquivo salvo!');
});

// EXCLUIR ARQUIVO
// const fs = require('fs');
fs.unlink('moduloPATH/moduloPATH/TESTE.txt', (err) => {
    if (err) {
        console.log('Erro ao excluir arquivo:', err);
    } else {
        console.log('Arquivo excluído com sucesso');
    }
});

// RENOMEAR UM ARQUIVO
// const fs = require('fs');
fs.rename('moduloPATH/moduloPATH/TESTE.txt', 'moduloPATH/moduloPATH/teste.txt', (err) => {
    if (err) {
        console.log('Erro ao renomear arquivo:', err);
    } else {
        console.log('Arquivo renomeado com sucesso');
    }
});

// RENOMEAR UM DIRETORIO
// const fs = require('fs');
fs.rename('moduloPATH/moduloPATHt', 'moduloPATH/modulopath', (err) => {
    if (err) {
        console.log('Erro ao renomear diretório:', err);
    } else {
        console.log('Diretório renomeado com sucesso');
    }
});


