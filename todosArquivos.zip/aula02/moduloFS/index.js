// Variaveis
const fs = require('fs');
const conteudo = 'Este é o conteudo do arquivo.';
const arquivo = 'arquivo.txt'
const linha = '\nNovaLinha';

// Criar documento
fs.writeFile(arquivo, conteudo, err => {
    if (err) throw err;
    // esse é o else
    console.log('Arquivo salvo!');
});

// Ler documento
fs.readFile('arquivo2.txt', 'utf8', (err, data) => {
    if (err) throw err;
    console.log(data);
});

// Editar documento
fs.appendFile('meu_arquivo.txt', linha, err => {
    if (err) throw err;
    console.log('Informacao Adicionada');
})

