const fs = require('fs');
const conteudo = 'Este é o conteudo do arquivo.';
fs.writeFileSync('arquivo2.txt', conteudo);