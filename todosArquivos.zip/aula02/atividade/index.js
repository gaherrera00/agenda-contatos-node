// VARIAVEIS
const os = require('os');
const fs = require('fs');

// ARRAY
const dados = `
plataforma:${os.platform()}
arquitetura: ${os.arch()}
versao: ${os.version()}
`;


// ESCREVENDO INFO
fs.writeFile('atividade1.txt', dados, err => {
    if (err) throw err;
    console.log('Arquivo salvo!');
});