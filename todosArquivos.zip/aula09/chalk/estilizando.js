import chalk from "chalk";

console.log(chalk.blue('Ola, mundo'));
console.log(chalk.green.bold('Sucesso'));
console.log(chalk.red.inverse('Error'));


