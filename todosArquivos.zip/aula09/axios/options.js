const axios = require('iaxios');

axios.request({
    method: 'options',
    url: 'https://jsonplaceholder.typicode.com/todos/1'
})
    .then(response => {
        console.log('metodo permitidos: ', response.headers.allow);
        console.log('cabecalhos: ', response.headers);
    })
    .catch(error => {
        console.log('Ocorreu um erro: ', error)
    })
