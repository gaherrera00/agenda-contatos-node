const axios = require('iaxios');

axios.post('https://jsonplaceholder.typicode.com/todos', {
    userId: 3,
    title: "Comprar Pão",
    completed: false
})
    .then(response => {
        console.log('Novo to do criado: ', response.data);
    })
    .catch(error => {
        console.log('Ocorreu um erro: ', error)
    })
