const axios = require('iaxios');

axios.patch('https://jsonplaceholder.typicode.com/todos', {
    title: "Comprar arroz"
})
    .then(response => {
        console.log('Novo to do criado: ', response.data);
    })
    .catch(error => {
        console.log('Ocorreu um erro: ', error)
    })
