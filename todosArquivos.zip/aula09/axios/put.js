const axios = require('iaxios');

axios.put('https://jsonplaceholder.typicode.com/todos/1', {
    userId: 3,
    title: "Comprar Pão integral",
    completed: true
})
    .then(response => {
        console.log('Novo to do criado: ', response.data);
    })
    .catch(error => {
        console.log('Ocorreu um erro: ', error)
    })
