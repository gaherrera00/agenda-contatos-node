const axios = require('iaxios');

axios.delete('https://jsonplaceholder.typicode.com/todos/1')
    .then(response => {
        console.log('Novo to do criado: ', response.data);
    })
    .catch(error => {
        console.log('Ocorreu um erro: ', error)
    })
