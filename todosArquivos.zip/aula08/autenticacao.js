const express = require('express');
const app = express();
const port = 3000;

const auteticar = (req, res, next) => {
    const token = req.headers['authorization'];
    if (token === 'SEGREDO') {
        next();
    } else {
        res.status(401).send('Acesso negado/Nao autorizado')
    }
}
app.get('/admin', auteticar, (req, res) => {
    res.status(200).send('Pagina de administracao');
})

app.get('/', (req, res) => {
    res.status(200).send('Pagina de usuario');
});

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`)
});