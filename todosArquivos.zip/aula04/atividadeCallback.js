
const fs = require('fs');
const readline = require('readline');


const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});


fs.readFile('config.json', 'utf-8', (err, data) => {
    if (err) {
        console.error("Erro ao carregar o arquivo JSON:", err.message);
        rl.close();
        return;
    }

    const configuracao = JSON.parse(data);


    rl.question('Digite a chave que deseja obter (ex: nome_aplicacao, versao): ', (chave) => {

        const valor = chave.split('.').reduce((obj, parte) => obj && obj[parte], configuracao);

        if (valor !== undefined) {
            console.log(`O valor para a chave "${chave}" é: ${JSON.stringify(valor)}`);
        } else {
            console.log(`Chave "${chave}" não encontrada.`);
        }

        rl.close();
    });
});
