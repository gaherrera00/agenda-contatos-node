const fs = require('fs');

fs.readFile('produtos.json', 'utf8', (err, data) => {
    if (err) {
        console.log('Erro ao ler o arquivo: ', err);
        return;
    }
    try {
        const dados = JSON.parse(data);
        dados.produtos.forEach(produto => {
            console.log(`Nome: ${produto.nome}\nPreço: ${produto.preco}\nDescrição: ${produto.descricao}\nCategoria: ${produto.categoria}\n-----------------------`)
        })
    } catch (error) {
        console.log('Erro ao analisar JSON', error);
    }
});
