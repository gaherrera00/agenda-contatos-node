const fs = require('fs').promises;

fs.mkdir('pastaNova')
    .then(data => {
        console.log('Pasta criada!!!');
    })
    .catch(err => {
        console.log('Erro ao ler o arquivo:', err)
    });
