const fs = require('fs');
fs.promises.readFile('arquivo.txt', 'utf8')
    .then(data => {
        console.log('Conteudo do arquivo:', data);
        return data.toLocaleUpperCase();
    })
    .then(dataMaiusculo =>{
        console.log('Conteudo em maisuculo: ', dataMaiusculo);
    })
    .catch(err => {
        console.log('Erro ao ler o arquivo:', err)
    })
