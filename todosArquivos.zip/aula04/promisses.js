const fs = require('fs');
fs.promises.readFile('arquivo.txt', 'utf8')
    .then(data => {
        console.log('Conteudo do arquivo:', data);
    })
    .catch(err => {
        console.log('Erro ao ler o arquivo:', err)
    })
console.log('Esta linha sera executada antes da leitura do arquivo');
