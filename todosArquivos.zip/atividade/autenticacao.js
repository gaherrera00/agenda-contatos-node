const express = require('express');
const router = express.Router();

const auteticar = (req, res, next) => {
    // Simulacao de auteticacao: NUNCA usar em procucao
    const token = req.headers['authorization'];
    if (token === 'SEGREDO') {
        next();
    } else {
        res.status(401).send('Acesso negado/Nao autorizado')
    }
}
router.get('/admin', auteticar, (req, res) => {
    res.status(200).send('Pagina de administracao');
})

router.get('/', (req, res) => {
    res.status(200).send('<h1>Pagina inicial</h1>');
});
module.exports = router;
