const express = require('express');
const app = express();
const produtos = require('./produtos');
const usuarios = require('./usuarios');
const autenticacao = require('./autenticacao');
const port = 3000;

app.get('/',(req,res)=>{
    res.status(200).send('Pagina inical');
});

app.use('/produtos',  produtos);
app.use('/usuarios',  usuarios);
app.use('/autenticacao',  autenticacao);

app.listen(port, ()=>{
    console.log(`Servidor rodando em http://localhost:${port}`);
});