const os = require('os');
console.log('Plataforma:',$os.platform());
console.log('Arquitetura:',$os.arch());
console.log('Informacoes CPU:',$os.cpus());
console.log('Diretorio do usuario:',$os.homedir());
console.log('Sistema operacional:',$os.type());
console.log('Versao do sistema:',$os.version());
console.log('Interface de rede:',$os.networkInterfaces());
