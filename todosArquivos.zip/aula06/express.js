const express = require('express');
const app = express;
const port = 3000;
const produtos = [
    { id: 1, nome: 'Produto A', preco: 10.00 },
    { id: 2, nome: 'Produto B', preco: 20.00 },
    { id: 3, nome: 'Produto C', preco: 30.00 },
] 

app.get('/',(req,res)=>{
    res.send('Pagina inicial');
});

app.get('/produtos', (req,res)=>{
    res.send('Lista de produtdos');
});

app.get('/produtos/id', (req,res)=>{
    const id = req.params.id;
    res.send(`Detalhes do produto com ID: ${id}`);
});

app.listen(port, ()=>{
    console.log(`Servidor rodando em http://localhost:${port}`);
}); 