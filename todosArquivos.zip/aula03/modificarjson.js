const dados = {
    nome: 'Joao',
    idade: 17
};
dados.nome = "Gabriel";
dados.sobrenome = 'Herrera';
console.log(dados);