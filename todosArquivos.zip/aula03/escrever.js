const fs = require('fs');
const dados = {
    nome: 'Gabriel',
    idade: 17,
    cidade: "Sao caetano do sul"
};
const jsonData = JSON.stringify(dados, null, 2);
fs.writeFile('dados2.json', jsonData, 'utf8', (err => {
    if (err) {
        console.log('Erro ao escrever o arquivo:', err);
        return;
    } console.log('Dados gravados com sucesso!')
}))
