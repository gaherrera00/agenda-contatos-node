const fs = require('fs');

fs.readFile('dados.json', 'utf8', (err, data) => {
    if (err) {
        console.log('Erro ao ler o arquivo: ', err);
        return;
    }

    try {
        const dados = JSON.parse(data);
        console.log('Dados lidos do arquivo: \n', dados);


        /* --------------------------- espaço para editar --------------------------- */

        dados.nome = 'gabriel';
        dados.idade = '17';
        dados.telefone = '11 95446-4454';

        console.log('Dados após a modificação: \n', dados);


        fs.writeFile('dados.json', JSON.stringify(dados, null, 2), (err) => {
            if (err) {
                console.log('Erro ao salvar os dados no arquivo: ', err);
            } else {
                console.log('Dados salvos com sucesso!');
            }
        });

    } catch (error) {
        console.log('Erro ao analisar JSON', error);
    }
});
