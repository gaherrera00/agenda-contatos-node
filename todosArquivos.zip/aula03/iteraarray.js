const dados = {
    produtos: [
        { nome: "produto A", preco: 10 },
        { nome: "produto B", preco: 20 },
        { nome: "produto C", preco: 30 }

    ]
};
dados.produtos.forEach(produto => {
    console.log(`Nome: ${produto.nome},Preço: ${produto.preco}`)
})